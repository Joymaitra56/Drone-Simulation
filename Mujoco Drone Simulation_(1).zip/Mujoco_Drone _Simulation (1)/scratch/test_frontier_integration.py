import mujoco
import sys
import os

# Append parent directory to imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from simulate import DroneAutopilot
from sensor_simulation import SensorSimulationSuite
from frontier_detection import FrontierDetection

def verify_frontier_integration():
    xml_path = "scene.xml"
    if not os.path.exists(xml_path):
        xml_path = os.path.join("..", "scene.xml")
        if not os.path.exists(xml_path):
            print(f"Error: {xml_path} not found!")
            sys.exit(1)
            
    print(f"Loading MuJoCo model from {xml_path}...")
    model = mujoco.MjModel.from_xml_path(xml_path)
    data  = mujoco.MjData(model)
    
    print("Instantiating DroneAutopilot and SensorSimulationSuite...")
    ap = DroneAutopilot(model, data)
    sensor_suite = SensorSimulationSuite(dt=model.opt.timestep)
    ap.sensor_suite = sensor_suite
    
    # Check that frontier_detector is instantiated
    print("Verifying instantiation of FrontierDetection...")
    assert hasattr(ap, "frontier_detector"), "Autopilot lacks frontier_detector attribute!"
    detector = ap.frontier_detector
    assert detector is not None, "frontier_detector is None!"
    
    print("Running initial simulation steps to trigger mapping and frontier extraction ticks...")
    # Step MuJoCo, sensor suite, and autopilot
    for _ in range(15):
        mujoco.mj_step(model, data)
        sensor_suite.step(model, data)
        ap.step()
        
    print("Querying frontier statistics...")
    count = detector.get_frontier_count()
    regions = detector.get_frontier_regions()
    
    print(f"Total detected frontier cells: {count}")
    print(f"Total clustered frontier regions: {len(regions)}")
    
    for r in regions:
        print(f"  Region ID {r['region_id']}: Size={r['size']} cells | Centroid={r['centroid_grid']} (Grid), {r['centroid_world']} (World) | Bbox={r['bbox']}")
        
    # Since pads are pre-revealed free areas and are surrounded by unexplored space,
    # there must be valid frontiers detected initially!
    assert count > 0, "No frontiers detected after simulation steps!"
    assert len(regions) > 0, "No frontier regions clustered after simulation steps!"
    
    print("\nFRONTIER DETECTION INTEGRATION VERIFICATION SUCCESSFUL!")

if __name__ == '__main__':
    verify_frontier_integration()

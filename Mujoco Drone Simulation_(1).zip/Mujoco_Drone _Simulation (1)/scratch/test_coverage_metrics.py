import unittest
import numpy as np
import time

# Add parent directory to imports
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from coverage_metrics import CoverageMetrics, CELL_UNKNOWN, CELL_FREE, CELL_OCCUPIED

class MockAutopilot:
    def __init__(self):
        self.grid_size = 160

class TestCoverageMetrics(unittest.TestCase):
    def setUp(self):
        self.mock_ap = MockAutopilot()
        self.metrics = CoverageMetrics(self.mock_ap)
        self.grid_shape = (self.mock_ap.grid_size, self.mock_ap.grid_size)

    def test_empty_grid(self):
        """Test coverage statistics with a completely unexplored grid."""
        grid = np.full(self.grid_shape, CELL_UNKNOWN, dtype=np.int8)
        self.metrics.update(grid, 0.0)
        
        self.assertEqual(self.metrics.get_explored_cells(), 0)
        self.assertEqual(self.metrics.get_unknown_cells(), 160 * 160)
        self.assertEqual(self.metrics.get_coverage_percentage(), 0.0)
        self.assertEqual(self.metrics.total_mapped_area, 0.0)
        self.assertEqual(self.metrics.exploration_efficiency, 0.0)

    def test_partial_coverage(self):
        """Test coverage with a partially mapped grid."""
        grid = np.full(self.grid_shape, CELL_UNKNOWN, dtype=np.int8)
        
        # Mark some cells free and occupied
        grid[0:10, 0:10] = CELL_FREE       # 100 cells
        grid[20:25, 20:25] = CELL_OCCUPIED  # 25 cells
        
        self.metrics.update(grid, 1.0)
        
        self.assertEqual(self.metrics.get_free_cells(), 100)
        self.assertEqual(self.metrics.get_occupied_cells(), 25)
        self.assertEqual(self.metrics.get_explored_cells(), 125)
        
        expected_pct = (125 / (160 * 160)) * 100.0
        self.assertAlmostEqual(self.metrics.get_coverage_percentage(), expected_pct)

    def test_full_coverage(self):
        """Test coverage with a completely mapped grid."""
        grid = np.full(self.grid_shape, CELL_FREE, dtype=np.int8)
        self.metrics.update(grid, 2.0)
        
        self.assertEqual(self.metrics.get_explored_cells(), 160 * 160)
        self.assertEqual(self.metrics.get_unknown_cells(), 0)
        self.assertEqual(self.metrics.get_coverage_percentage(), 100.0)

    def test_reset(self):
        """Test reset clears statistics and history."""
        grid = np.full(self.grid_shape, CELL_FREE, dtype=np.int8)
        self.metrics.update(grid, 1.0)
        self.assertEqual(self.metrics.get_explored_cells(), 160 * 160)
        self.assertGreater(len(self.metrics.history), 0)
        
        self.metrics.reset()
        self.assertEqual(self.metrics.get_explored_cells(), 0)
        self.assertEqual(self.metrics.get_coverage_percentage(), 0.0)
        self.assertEqual(len(self.metrics.history), 0)

    def test_continuous_update_and_growth_rate(self):
        """Test continuous updates, elapsed time progress, and coverage growth rate calculation."""
        grid = np.full(self.grid_shape, CELL_UNKNOWN, dtype=np.int8)
        
        # Step 1: t=0.0, 0 explored cells
        self.metrics.update(grid, 0.0)
        self.assertEqual(self.metrics.elapsed_time, 0.0)
        self.assertEqual(self.metrics.coverage_growth_rate, 0.0)
        
        # Step 2: t=0.5, 256 cells free (~1% coverage)
        grid[0:16, 0:16] = CELL_FREE
        self.metrics.update(grid, 0.5)
        self.assertEqual(self.metrics.elapsed_time, 0.5)
        
        # Step 3: t=1.0, 512 cells free (~2% coverage)
        grid[16:32, 0:16] = CELL_FREE
        self.metrics.update(grid, 1.0)
        
        # Check growth rate (grew by ~1% in 0.5 seconds -> ~2%/sec rate)
        growth = self.metrics.coverage_growth_rate
        self.assertGreater(growth, 1.5)
        self.assertLess(growth, 2.5)

    def test_performance_overhead(self):
        """Benchmark performance and verify negligible update overhead (< 1ms)."""
        grid = np.full(self.grid_shape, CELL_UNKNOWN, dtype=np.int8)
        grid[0:50, 0:50] = CELL_FREE
        
        iterations = 5000
        t_start = time.perf_counter()
        for i in range(iterations):
            self.metrics.update(grid, float(i) * 0.005)
        t_end = time.perf_counter()
        
        elapsed = t_end - t_start
        avg_time = elapsed / iterations
        print(f"\n[COVERAGE BENCHMARK] Elapsed: {elapsed:.4f}s for {iterations} iterations.")
        print(f"[COVERAGE BENCHMARK] Average overhead: {avg_time * 1e6:.3f} microseconds.")
        
        # Assert average overhead is well below 1 millisecond (0.001 seconds)
        self.assertLess(avg_time, 0.001)

if __name__ == '__main__':
    unittest.main()

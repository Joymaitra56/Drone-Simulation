import re

with open('generate_pdf.py', 'r', encoding='utf-8') as f:
    content = f.read()

content = re.sub(r't = Table\(([^,]+),\s*colWidths=([^)]+)\)\n\s*t\.setStyle\(_ts\(\)\)',
                 r't = make_table(\1, colWidths=\2)', content)

content = content.replace('"Neon Grid Drone Simulation"', '"Drone Simulation"')
content = content.replace('"Comprehensive Research Project Report"', '"Project Report"')
content = content.replace('"Autonomous Terrain Exploration, Incremental Map Building, Dynamic Path Replanning, "\n        "and Behaviour-Based Control in a Physics-Driven Quadcopter Simulation"',
                          '"Autonomous Navigation and Obstacle Avoidance Simulation"')

headers_map = {
    "1. Introduction &amp; Research Objectives": "1. Introduction",
    "1. Introduction & Research Objectives": "1. Introduction",
    "2. System Architecture Overview": "2. Architecture Overview",
    "3. Physics-Based Drone Controller": "3. Drone Controller",
    "4. Occupancy Grid &amp; Map Generation": "4. Map Generation",
    "4. Occupancy Grid & Map Generation": "4. Map Generation",
    "5. Pathfinding: A* vs Dijkstra — Comparative Analysis": "5. Pathfinding (A* vs Dijkstra)",
    "5. Pathfinding: A* vs Dijkstra - Comparative Analysis": "5. Pathfinding (A* vs Dijkstra)",
    "6. Terrain Scanning &amp; Incremental Map Building (Feature 1)": "6. Terrain Scanning",
    "6. Terrain Scanning & Incremental Map Building (Feature 1)": "6. Terrain Scanning",
    "7. Dynamic Obstacle Replanning (Feature 2)": "7. Obstacle Avoidance",
    "8. Subsumption Architecture (Feature 3)": "8. Behavior Priorities",
    "9. Software Sensor Simulation": "9. Sensor Simulation",
    "10. State Estimation Filters — Comparative Analysis": "10. State Estimation Filters",
    "10. State Estimation Filters - Comparative Analysis": "10. State Estimation Filters",
    "11. Experimental Results &amp; Discussion": "11. Experimental Results",
    "11. Experimental Results & Discussion": "11. Experimental Results",
    "12. System Integration &amp; Workflow": "12. System Workflow",
    "12. System Integration & Workflow": "12. System Workflow",
    "13. Conclusion &amp; Future Work": "13. Conclusion",
    "13. Conclusion & Future Work": "13. Conclusion",
}

for old, new in headers_map.items():
    content = content.replace('"' + old + '"', '"' + new + '"')

with open('generate_pdf.py', 'w', encoding='utf-8') as f:
    f.write(content)

print('Replacements applied successfully.')

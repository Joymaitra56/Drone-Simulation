import unittest
from mission_state import MissionState
from mission_manager import MissionManager

class TestMissionManager(unittest.TestCase):
    def setUp(self):
        self.manager = MissionManager(MissionState.IDLE)

    def test_initial_state(self):
        self.assertEqual(self.manager.get_state(), MissionState.IDLE)
        self.assertTrue(self.manager.is_in_state(MissionState.IDLE))

    def test_valid_transitions(self):
        # IDLE -> TAKEOFF
        self.assertTrue(self.manager.transition_to(MissionState.TAKEOFF))
        self.assertEqual(self.manager.get_state(), MissionState.TAKEOFF)

        # TAKEOFF -> EXPLORE
        self.assertTrue(self.manager.transition_to(MissionState.EXPLORE))
        self.assertEqual(self.manager.get_state(), MissionState.EXPLORE)

        # EXPLORE -> RETURN_HOME
        self.assertTrue(self.manager.transition_to(MissionState.RETURN_HOME))
        self.assertEqual(self.manager.get_state(), MissionState.RETURN_HOME)

        # RETURN_HOME -> LAND
        self.assertTrue(self.manager.transition_to(MissionState.LAND))
        self.assertEqual(self.manager.get_state(), MissionState.LAND)

        # LAND -> MISSION_COMPLETE
        self.assertTrue(self.manager.transition_to(MissionState.MISSION_COMPLETE))
        self.assertEqual(self.manager.get_state(), MissionState.MISSION_COMPLETE)

    def test_invalid_transitions(self):
        # IDLE -> EXPLORE is invalid
        self.assertFalse(self.manager.transition_to(MissionState.EXPLORE))
        self.assertEqual(self.manager.get_state(), MissionState.IDLE)

        # Transition to TAKEOFF
        self.manager.transition_to(MissionState.TAKEOFF)
        # TAKEOFF -> MISSION_COMPLETE is invalid
        self.assertFalse(self.manager.transition_to(MissionState.MISSION_COMPLETE))
        self.assertEqual(self.manager.get_state(), MissionState.TAKEOFF)

    def test_emergency_transitions(self):
        # Any state can go to EMERGENCY
        self.assertTrue(self.manager.transition_to(MissionState.EMERGENCY))
        self.assertEqual(self.manager.get_state(), MissionState.EMERGENCY)

        # EMERGENCY can go to LAND
        self.setUp()
        self.manager.transition_to(MissionState.TAKEOFF)
        self.manager.transition_to(MissionState.EMERGENCY)
        self.assertTrue(self.manager.transition_to(MissionState.LAND))

    def test_forced_state(self):
        # Force transitions ignoring transition validation rules
        self.manager.force_state(MissionState.EXPLORE)
        self.assertEqual(self.manager.get_state(), MissionState.EXPLORE)

    def test_reset(self):
        self.manager.transition_to(MissionState.TAKEOFF)
        self.manager.reset()
        self.assertEqual(self.manager.get_state(), MissionState.IDLE)

if __name__ == '__main__':
    unittest.main()

import unittest
import math
import time
import numpy as np
from typing import Any

# Add parent directory to imports
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from sensor_fusion import SensorFusion, FusedState

# Minimal mock classes to avoid loading full MuJoCo simulation for raw unit tests
class MockKalmanFilter:
    def __init__(self, pos: float, vel: float):
        self.x = np.array([pos, vel], dtype=np.float64)

class MockPhysics:
    def _quat_rpy(self, q: Any):
        # returns roll, pitch, yaw (yaw is index 2)
        return 0.1, -0.1, 1.25

class MockData:
    def __init__(self):
        self.time = 42.0
        self.xquat = {99: np.array([1.0, 0.0, 0.0, 0.0])} # Mock dict or index access

class MockSensorSuite:
    def __init__(self):
        self.kf_x = MockKalmanFilter(1.2, 0.5)
        self.kf_y = MockKalmanFilter(-3.4, -0.2)
        self.kf_z = MockKalmanFilter(5.6, 0.1)
        self.comp_roll = 0.05
        self.comp_pitch = -0.04
        self.ema_alt = 1.45
        self.ema_front = 8.2

class MockAutopilot:
    def __init__(self):
        self.drone_body_id = 99
        self.data = MockData()
        self.physics = MockPhysics()
        self.sensor_suite = MockSensorSuite()

class TestSensorFusion(unittest.TestCase):
    def setUp(self):
        self.mock_ap = MockAutopilot()
        self.fusion = SensorFusion(self.mock_ap)

    def test_initialization(self):
        """Test default values upon initialization."""
        state = self.fusion.get_state()
        self.assertFalse(state.valid)
        self.assertEqual(state.x, 0.0)
        self.assertEqual(state.y, 0.0)
        self.assertEqual(state.z, 0.0)
        self.assertEqual(state.vx, 0.0)
        
        health = self.fusion.get_health_status()
        self.assertTrue(health["sensor_suite_connected"])
        self.assertTrue(health["filters_initialized"])
        self.assertFalse(health["state_estimate_valid"])

    def test_continuous_update(self):
        """Test updating state values continuously."""
        self.fusion.update()
        state = self.fusion.get_state()
        
        self.assertTrue(state.valid)
        self.assertAlmostEqual(state.x, 1.2)
        self.assertAlmostEqual(state.y, -3.4)
        self.assertAlmostEqual(state.z, 5.6)
        self.assertAlmostEqual(state.vx, 0.5)
        self.assertAlmostEqual(state.vy, -0.2)
        self.assertAlmostEqual(state.vz, 0.1)
        self.assertAlmostEqual(state.roll, 0.05)
        self.assertAlmostEqual(state.pitch, -0.04)
        self.assertAlmostEqual(state.yaw, 1.25)
        self.assertAlmostEqual(state.ema_alt, 1.45)
        self.assertAlmostEqual(state.ema_front, 8.2)
        self.assertAlmostEqual(state.timestamp, 42.0)

        # Alter mock state and verify update tracks
        self.mock_ap.sensor_suite.kf_x.x[0] = 1.3
        self.mock_ap.data.time = 42.005
        self.fusion.update()
        
        state_updated = self.fusion.get_state()
        self.assertAlmostEqual(state_updated.x, 1.3)
        self.assertAlmostEqual(state_updated.timestamp, 42.005)

    def test_reset(self):
        """Test reset puts internal values back to zero/invalid."""
        self.fusion.update()
        self.assertTrue(self.fusion.get_state().valid)
        
        self.fusion.reset()
        state = self.fusion.get_state()
        self.assertFalse(state.valid)
        self.assertEqual(state.x, 0.0)
        self.assertEqual(state.timestamp, 0.0)

    def test_invalid_sensor_data_handling(self):
        """Test robustness when sensor suite contains NaNs or errors."""
        # Case A: sensor_suite is None
        self.mock_ap.sensor_suite = None
        self.fusion.update()
        self.assertFalse(self.fusion.get_state().valid)

        # Case B: NaN inserted into Kalman filter pos
        self.mock_ap.sensor_suite = MockSensorSuite()
        self.mock_ap.sensor_suite.kf_x.x[0] = float('nan')
        self.fusion.update()
        
        # State update should mark valid = True (values are parsed),
        # but get_health_status will show state_estimate_sane = False.
        health = self.fusion.get_health_status()
        self.assertTrue(health["state_estimate_valid"])
        self.assertFalse(health["state_estimate_sane"])

        # Case C: Exception thrown during attribute reading
        # We delete kf_x to trigger an exception in update
        del self.mock_ap.sensor_suite.kf_x
        self.fusion.update()
        self.assertFalse(self.fusion.get_state().valid)

    def test_performance_overhead(self):
        """Verify performance overhead is negligible (e.g. < 0.1ms per update)."""
        # Re-initialize with clean mocks
        self.setUp()
        
        iterations = 10000
        t_start = time.perf_counter()
        for _ in range(iterations):
            self.fusion.update()
        t_end = time.perf_counter()
        
        elapsed = t_end - t_start
        avg_time = elapsed / iterations
        
        print(f"\n[PERF BENCHMARK] Total: {elapsed:.4f}s for {iterations} iterations.")
        print(f"[PERF BENCHMARK] Average update overhead: {avg_time * 1e6:.3f} microseconds.")
        
        # Ensure average execution is well below 100 microseconds (0.1 milliseconds)
        self.assertLess(avg_time, 0.0001)

if __name__ == '__main__':
    unittest.main()

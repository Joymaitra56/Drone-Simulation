import unittest
import numpy as np
import time

# Add parent directory to imports
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from frontier_detection import FrontierDetection, CELL_UNKNOWN, CELL_FREE, CELL_OCCUPIED

class MockAutopilot:
    def __init__(self):
        self.grid_size = 160
        self.scanner = None

class TestFrontierDetection(unittest.TestCase):
    def setUp(self):
        self.mock_ap = MockAutopilot()
        self.detector = FrontierDetection(self.mock_ap, connectivity=8)
        self.grid_shape = (self.mock_ap.grid_size, self.mock_ap.grid_size)

    def test_empty_grid(self):
        """Test detection with a completely unexplored grid."""
        grid = np.full(self.grid_shape, CELL_UNKNOWN, dtype=np.int8)
        self.detector.update(grid)
        
        self.assertEqual(self.detector.get_frontier_count(), 0)
        self.assertEqual(len(self.detector.get_frontier_regions()), 0)

    def test_fully_explored_grid(self):
        """Test detection with a fully explored grid containing zero unknown cells."""
        grid = np.full(self.grid_shape, CELL_FREE, dtype=np.int8)
        self.detector.update(grid)
        
        self.assertEqual(self.detector.get_frontier_count(), 0)
        self.assertEqual(len(self.detector.get_frontier_regions()), 0)

    def test_single_frontier(self):
        """Test detection of a single boundary cell adjacent to unknown cells."""
        grid = np.full(self.grid_shape, CELL_UNKNOWN, dtype=np.int8)
        
        # Mark one cell as FREE
        grid[80, 80] = CELL_FREE
        self.detector.update(grid)
        
        self.assertEqual(self.detector.get_frontier_count(), 1)
        self.assertEqual(self.detector.get_frontiers(), [(80, 80)])
        
        regions = self.detector.get_frontier_regions()
        self.assertEqual(len(regions), 1)
        self.assertEqual(regions[0]["size"], 1)
        self.assertEqual(regions[0]["centroid_grid"], (80.0, 80.0))

    def test_multiple_frontier_regions(self):
        """Test clustering of multiple disconnected frontier regions."""
        grid = np.full(self.grid_shape, CELL_UNKNOWN, dtype=np.int8)
        
        # Disconnected FREE cells
        grid[40, 40] = CELL_FREE
        grid[120, 120] = CELL_FREE
        self.detector.update(grid)
        
        self.assertEqual(self.detector.get_frontier_count(), 2)
        regions = self.detector.get_frontier_regions()
        self.assertEqual(len(regions), 2)
        
        # Assert unique region IDs
        ids = {r["region_id"] for r in regions}
        self.assertEqual(ids, {1, 2})

    def test_region_merging(self):
        """Test that adjacent frontier cells are merged into a single component."""
        grid = np.full(self.grid_shape, CELL_UNKNOWN, dtype=np.int8)
        
        # Continuous strip of FREE cells
        grid[80, 80] = CELL_FREE
        grid[80, 81] = CELL_FREE
        grid[80, 82] = CELL_FREE
        self.detector.update(grid)
        
        self.assertEqual(self.detector.get_frontier_count(), 3)
        regions = self.detector.get_frontier_regions()
        self.assertEqual(len(regions), 1)
        self.assertEqual(regions[0]["size"], 3)
        
        # Centroid check
        self.assertAlmostEqual(regions[0]["centroid_grid"][0], 81.0)
        self.assertAlmostEqual(regions[0]["centroid_grid"][1], 80.0)
        
        # Bounding box check (min_gx, min_gy, max_gx, max_gy)
        self.assertEqual(regions[0]["bbox"], (80, 80, 82, 80))

    def test_neighbor_connectivity_comparison(self):
        """Compare 4-neighbor vs 8-neighbor connectivity for diagonally adjacent cells."""
        grid = np.full(self.grid_shape, CELL_UNKNOWN, dtype=np.int8)
        
        # Diagonally adjacent FREE cells
        grid[80, 80] = CELL_FREE
        grid[81, 81] = CELL_FREE
        
        # 1. 8-Neighbor Connectivity (should merge into 1 region)
        self.detector.connectivity = 8
        self.detector.update(grid)
        self.assertEqual(len(self.detector.get_frontier_regions()), 1)
        
        # 2. 4-Neighbor Connectivity (should form 2 separate regions)
        detector_4 = FrontierDetection(self.mock_ap, connectivity=4)
        detector_4.update(grid)
        self.assertEqual(len(detector_4.get_frontier_regions()), 2)

    def test_deterministic_output(self):
        """Validate that running updates on identical grids produces identical results."""
        grid = np.full(self.grid_shape, CELL_UNKNOWN, dtype=np.int8)
        grid[80, 80:85] = CELL_FREE
        
        self.detector.update(grid)
        c1 = list(self.detector.get_frontiers())
        r1 = list(self.detector.get_frontier_regions())
        
        self.detector.update(grid)
        c2 = list(self.detector.get_frontiers())
        r2 = list(self.detector.get_frontier_regions())
        
        self.assertEqual(c1, c2)
        self.assertEqual(len(r1), len(r2))
        for i in range(len(r1)):
            self.assertEqual(r1[i]["region_id"], r2[i]["region_id"])
            self.assertEqual(r1[i]["size"], r2[i]["size"])
            self.assertEqual(r1[i]["centroid_grid"], r2[i]["centroid_grid"])

    def test_performance_overhead(self):
        """Verify execution overhead is negligible (< 1ms)."""
        grid = np.full(self.grid_shape, CELL_UNKNOWN, dtype=np.int8)
        # Construct a large circle of free cells to create a substantial frontier border
        for r in range(160):
            for c in range(160):
                if 20 <= np.sqrt((r-80)**2 + (c-80)**2) <= 22:
                    grid[r, c] = CELL_FREE
                    
        iterations = 100
        t_start = time.perf_counter()
        for _ in range(iterations):
            self.detector.update(grid)
        t_end = time.perf_counter()
        
        elapsed = t_end - t_start
        avg_time = elapsed / iterations
        print(f"\n[FRONTIER BENCHMARK] Elapsed: {elapsed:.4f}s for {iterations} iterations.")
        print(f"[FRONTIER BENCHMARK] Average overhead: {avg_time * 1e3:.3f} milliseconds.")
        
        # Verify average execution time is under 1 millisecond
        self.assertLess(avg_time, 0.001)

if __name__ == '__main__':
    unittest.main()

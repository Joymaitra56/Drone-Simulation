import mujoco
import sys
import os

# Append parent directory to imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from simulate import DroneAutopilot
from sensor_simulation import SensorSimulationSuite
from sensor_fusion import SensorFusion
from occupancy_grid_mapping import OccupancyGridMapping

def verify_mapping_integration():
    xml_path = "scene.xml"
    if not os.path.exists(xml_path):
        xml_path = os.path.join("..", "scene.xml")
        if not os.path.exists(xml_path):
            print(f"Error: {xml_path} not found!")
            sys.exit(1)
            
    print(f"Loading MuJoCo model from {xml_path}...")
    model = mujoco.MjModel.from_xml_path(xml_path)
    data  = mujoco.MjData(model)
    
    print("Instantiating DroneAutopilot and SensorSimulationSuite...")
    ap = DroneAutopilot(model, data)
    sensor_suite = SensorSimulationSuite(dt=model.opt.timestep)
    ap.sensor_suite = sensor_suite
    
    # Attach occupancy_mapper as is done in the run_simulation setup
    print("Verifying instantiation of OccupancyGridMapping...")
    assert hasattr(ap, "occupancy_mapper"), "Autopilot lacks occupancy_mapper attribute!"
    mapper = ap.occupancy_mapper
    assert mapper is not None, "occupancy_mapper is None!"
    
    print("Running initial simulation steps to trigger mapping updates...")
    # Step MuJoCo and Sensor Suite
    for _ in range(10):
        mujoco.mj_step(model, data)
        sensor_suite.step(model, data)
        ap.step()
        
    print("Querying mapper statistics...")
    stats = mapper.get_statistics()
    print(f"Total cells: {stats['total_cells']}")
    print(f"Explored cells: {stats['explored_cells']}")
    print(f"Unknown cells: {stats['unknown_cells']}")
    print(f"Free cells: {stats['free_cells']}")
    print(f"Occupied cells: {stats['occupied_cells']}")
    print(f"Coverage percentage: {stats['coverage_percentage']:.2f}%")
    
    assert stats["explored_cells"] > 0, "No cells explored after mapping ticks!"
    assert stats["coverage_percentage"] > 0.0, "Coverage percentage remains 0.0%!"
    
    print("\nOCCUPANCY MAPPING INTEGRATION VERIFICATION SUCCESSFUL!")

if __name__ == '__main__':
    verify_mapping_integration()

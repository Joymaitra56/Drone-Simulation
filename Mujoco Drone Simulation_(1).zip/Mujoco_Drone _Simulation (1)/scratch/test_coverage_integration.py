import mujoco
import sys
import os

# Append parent directory to imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from simulate import DroneAutopilot
from sensor_simulation import SensorSimulationSuite
from coverage_metrics import CoverageMetrics

def verify_coverage_integration():
    xml_path = "scene.xml"
    if not os.path.exists(xml_path):
        xml_path = os.path.join("..", "scene.xml")
        if not os.path.exists(xml_path):
            print(f"Error: {xml_path} not found!")
            sys.exit(1)
            
    print(f"Loading MuJoCo model from {xml_path}...")
    model = mujoco.MjModel.from_xml_path(xml_path)
    data  = mujoco.MjData(model)
    
    print("Instantiating DroneAutopilot and SensorSimulationSuite...")
    ap = DroneAutopilot(model, data)
    sensor_suite = SensorSimulationSuite(dt=model.opt.timestep)
    ap.sensor_suite = sensor_suite
    
    # Check that coverage_analyzer is instantiated
    print("Verifying instantiation of CoverageMetrics...")
    assert hasattr(ap, "coverage_analyzer"), "Autopilot lacks coverage_analyzer attribute!"
    analyzer = ap.coverage_analyzer
    assert analyzer is not None, "coverage_analyzer is None!"
    
    # Check initial values (should read the pre-revealed landing pads)
    initial_cov = analyzer.get_coverage_percentage()
    print(f"Initial pre-revealed coverage: {initial_cov:.2f}%")
    assert initial_cov > 0.0, "Initial coverage must be non-zero due to landing pad pre-revealing!"
    
    print("Running simulation steps to trigger mapping and analysis ticks...")
    # Step MuJoCo, sensor suite, and autopilot
    for _ in range(10):
        mujoco.mj_step(model, data)
        sensor_suite.step(model, data)
        ap.step()
        
    print("Verifying updated CoverageMetrics stats...")
    stats = analyzer.get_statistics()
    print(f"Total cells: {stats['total_cells']}")
    print(f"Explored cells: {stats['explored_cells']}")
    print(f"Unknown cells: {stats['unknown_cells']}")
    print(f"Free cells: {stats['free_cells']}")
    print(f"Occupied cells: {stats['occupied_cells']}")
    print(f"Coverage percentage: {stats['coverage_percentage']:.2f}%")
    print(f"Coverage growth rate: {stats['coverage_growth_rate']:.4f}%/s")
    print(f"Mapped area: {stats['total_mapped_area_m2']:.2f} m^2")
    print(f"Exploration efficiency: {stats['exploration_efficiency_m2_per_sec']:.4f} m^2/s")
    print(f"Elapsed time: {stats['elapsed_time_seconds']:.4f} s")
    
    assert stats["explored_cells"] > 0, "No cells explored!"
    assert stats["elapsed_time_seconds"] > 0.0, "Elapsed time not tracking!"
    
    print("\nCOVERAGE METRICS INTEGRATION VERIFICATION SUCCESSFUL!")

if __name__ == '__main__':
    verify_coverage_integration()

import mujoco
import sys
import os

# Append parent directory to imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from simulate import DroneAutopilot
from sensor_simulation import SensorSimulationSuite
from sensor_fusion import SensorFusion
from mission_state import MissionState

def verify_sensor_integration():
    xml_path = "scene.xml"
    if not os.path.exists(xml_path):
        xml_path = os.path.join("..", "scene.xml")
        if not os.path.exists(xml_path):
            print(f"Error: {xml_path} not found!")
            sys.exit(1)
            
    print(f"Loading MuJoCo model from {xml_path}...")
    model = mujoco.MjModel.from_xml_path(xml_path)
    data  = mujoco.MjData(model)
    
    print("Instantiating DroneAutopilot and SensorSimulationSuite...")
    ap = DroneAutopilot(model, data)
    sensor_suite = SensorSimulationSuite(dt=model.opt.timestep)
    
    # Attach sensor_suite as is done in the run_simulation setup
    ap.sensor_suite = sensor_suite
    
    print("Checking initial SensorFusion state (should be invalid/un-updated)...")
    assert hasattr(ap, "sensor_fusion"), "Autopilot lacks sensor_fusion attribute!"
    initial_state = ap.sensor_fusion.get_state()
    assert not initial_state.valid, "SensorFusion should be invalid before first sensor step!"
    
    print("Running initial simulation step to populate filters...")
    # Step MuJoCo and Sensor Suite
    mujoco.mj_step(model, data)
    sensor_suite.step(model, data)
    
    # Step autopilot (which triggers sensor_fusion update inside the step hook)
    ap.step()
    
    print("Verifying updated state values...")
    fused_state = ap.sensor_fusion.get_state()
    assert fused_state.valid, "SensorFusion state should be valid after step!"
    
    # Check alignment of coordinates
    print(f"Fused position: ({fused_state.x:.4f}, {fused_state.y:.4f}, {fused_state.z:.4f})")
    print(f"Kalman Filter position: ({sensor_suite.kf_x.x[0]:.4f}, {sensor_suite.kf_y.x[0]:.4f}, {sensor_suite.kf_z.x[0]:.4f})")
    
    assert abs(fused_state.x - sensor_suite.kf_x.x[0]) < 1e-7, "X estimate discrepancy!"
    assert abs(fused_state.y - sensor_suite.kf_y.x[0]) < 1e-7, "Y estimate discrepancy!"
    assert abs(fused_state.z - sensor_suite.kf_z.x[0]) < 1e-7, "Z estimate discrepancy!"
    
    # Verify RPY extraction
    print(f"Fused Attitude: roll={fused_state.roll:.4f}, pitch={fused_state.pitch:.4f}, yaw={fused_state.yaw:.4f}")
    assert abs(fused_state.roll - sensor_suite.comp_roll) < 1e-7, "Roll attitude discrepancy!"
    assert abs(fused_state.pitch - sensor_suite.comp_pitch) < 1e-7, "Pitch attitude discrepancy!"
    
    print("\nSENSOR INTEGRATION VERIFICATION SUCCESSFUL!")

if __name__ == '__main__':
    verify_sensor_integration()

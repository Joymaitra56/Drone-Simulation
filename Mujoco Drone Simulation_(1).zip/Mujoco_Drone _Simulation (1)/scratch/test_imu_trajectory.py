"""
Unit tests for imu_trajectory.py

Tests cover:
  - TrajectoryRecorder: gating, recording, distance filtering, control
  - TrajectoryReplayer: smoothing, reversal, arrival/home detection, progress
"""

import math
import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from sensor_fusion import FusedState
from imu_trajectory import TrajectoryRecorder, TrajectoryReplayer, TrajectorySnapshot


def _make_state(x=0.0, y=0.0, z=1.5, yaw=0.0, vx=0.0, vy=0.0, vz=0.0, t=0.0, valid=True):
    """Helper: construct a FusedState with the given values."""
    return FusedState(x=x, y=y, z=z, vx=vx, vy=vy, vz=vz,
                     roll=0.0, pitch=0.0, yaw=yaw,
                     ema_alt=z, ema_front=5.0, timestamp=t, valid=valid)


# ---------------------------------------------------------------------------
# TrajectoryRecorder tests
# ---------------------------------------------------------------------------

class TestTrajectoryRecorder(unittest.TestCase):

    def _make_recorder(self, record_hz=10.0, min_dist=0.05):
        r = TrajectoryRecorder(record_hz=record_hz, min_dist_m=min_dist)
        r.start()
        return r

    # ── basic recording ────────────────────────────────────────────────────

    def test_not_recording_when_stopped(self):
        r = TrajectoryRecorder(record_hz=10.0)
        # is_recording starts False
        state = _make_state(t=0.0)
        result = r.record(state)
        self.assertFalse(result)
        self.assertEqual(r.snapshot_count(), 0)

    def test_invalid_state_not_recorded(self):
        r = self._make_recorder()
        state = _make_state(valid=False, t=0.0)
        result = r.record(state)
        self.assertFalse(result)

    def test_first_sample_always_recorded(self):
        r = self._make_recorder(record_hz=10.0, min_dist=0.05)
        state = _make_state(x=1.0, y=1.0, t=0.0)
        result = r.record(state)
        self.assertTrue(result)
        self.assertEqual(r.snapshot_count(), 1)

    # ── time gate ─────────────────────────────────────────────────────────

    def test_time_gate_blocks_rapid_samples(self):
        r = self._make_recorder(record_hz=10.0, min_dist=0.0)  # disable distance gate
        r.record(_make_state(x=0.0, y=0.0, t=0.0))
        # 0.05 s < 0.1 s interval → blocked
        result = r.record(_make_state(x=5.0, y=5.0, t=0.05))
        self.assertFalse(result)
        self.assertEqual(r.snapshot_count(), 1)

    def test_time_gate_allows_sample_after_interval(self):
        r = self._make_recorder(record_hz=10.0, min_dist=0.0)
        r.record(_make_state(x=0.0, y=0.0, t=0.0))
        # 0.1 s == interval → allowed
        result = r.record(_make_state(x=5.0, y=5.0, t=0.1))
        self.assertTrue(result)
        self.assertEqual(r.snapshot_count(), 2)

    # ── distance gate ──────────────────────────────────────────────────────

    def test_distance_gate_blocks_stationary(self):
        r = self._make_recorder(record_hz=10.0, min_dist=0.05)
        r.record(_make_state(x=0.0, y=0.0, t=0.0))
        # Drone barely moved (< 0.05 m) — blocked
        result = r.record(_make_state(x=0.01, y=0.01, t=0.5))
        self.assertFalse(result)
        self.assertEqual(r.snapshot_count(), 1)

    def test_distance_gate_allows_significant_movement(self):
        r = self._make_recorder(record_hz=10.0, min_dist=0.05)
        r.record(_make_state(x=0.0, y=0.0, t=0.0))
        # Moved > 0.05 m → allowed
        result = r.record(_make_state(x=1.0, y=0.0, t=0.5))
        self.assertTrue(result)
        self.assertEqual(r.snapshot_count(), 2)

    # ── control ────────────────────────────────────────────────────────────

    def test_stop_prevents_recording(self):
        r = self._make_recorder()
        r.record(_make_state(x=0.0, y=0.0, t=0.0))
        r.stop()
        result = r.record(_make_state(x=5.0, y=5.0, t=1.0))
        self.assertFalse(result)
        self.assertEqual(r.snapshot_count(), 1)

    def test_clear_resets_log(self):
        r = self._make_recorder()
        r.record(_make_state(x=0.0, y=0.0, t=0.0))
        r.record(_make_state(x=1.0, y=0.0, t=0.5))
        r.clear()
        self.assertEqual(r.snapshot_count(), 0)
        # Can record again after clear
        result = r.record(_make_state(x=0.0, y=0.0, t=0.0))
        self.assertTrue(result)

    # ── path length ────────────────────────────────────────────────────────

    def test_total_distance_empty(self):
        r = self._make_recorder()
        self.assertAlmostEqual(r.get_total_distance_m(), 0.0)

    def test_total_distance_single_point(self):
        r = self._make_recorder(min_dist=0.0)
        r.record(_make_state(x=0.0, y=0.0, t=0.0))
        self.assertAlmostEqual(r.get_total_distance_m(), 0.0)

    def test_total_distance_two_points(self):
        r = self._make_recorder(record_hz=1.0, min_dist=0.0)
        r.record(_make_state(x=0.0, y=0.0, t=0.0))
        r.record(_make_state(x=3.0, y=4.0, t=2.0))
        self.assertAlmostEqual(r.get_total_distance_m(), 5.0, places=5)

    # ── snapshot content ──────────────────────────────────────────────────

    def test_snapshot_values_match_state(self):
        r = self._make_recorder()
        state = _make_state(x=2.0, y=3.0, z=1.5, yaw=0.5, vx=1.0, vy=-0.5, t=0.0)
        r.record(state)
        snap = r.get_log()[0]
        self.assertAlmostEqual(snap.x,   2.0)
        self.assertAlmostEqual(snap.y,   3.0)
        self.assertAlmostEqual(snap.z,   1.5)
        self.assertAlmostEqual(snap.yaw, 0.5)
        self.assertAlmostEqual(snap.vx,  1.0)
        self.assertAlmostEqual(snap.vy, -0.5)
        self.assertAlmostEqual(snap.timestamp, 0.0)


# ---------------------------------------------------------------------------
# TrajectoryReplayer tests
# ---------------------------------------------------------------------------

def _build_log(positions):
    """Helper: build a log from a list of (x, y, z, t) tuples."""
    snaps = []
    for x, y, z, t in positions:
        snaps.append(TrajectorySnapshot(timestamp=t, x=x, y=y, z=z,
                                        yaw=0.0, vx=0.0, vy=0.0, vz=0.0))
    return snaps


class TestTrajectoryReplayer(unittest.TestCase):

    HOME = (-4.0, -4.0)

    def _make_replayer(self, arrival=0.45, home_radius=0.40):
        return TrajectoryReplayer(
            arrival_radius_m=arrival,
            home_pos=self.HOME,
            home_radius_m=home_radius,
        )

    # ── start / reset ──────────────────────────────────────────────────────

    def test_start_with_empty_log_returns_false(self):
        r = self._make_replayer()
        result = r.start([])
        self.assertFalse(result)
        self.assertFalse(r.is_active)

    def test_start_with_valid_log_returns_true(self):
        r = self._make_replayer()
        log = _build_log([(0, 0, 1.5, 0), (1, 0, 1.5, 1)])
        result = r.start(log)
        self.assertTrue(result)
        self.assertTrue(r.is_active)
        self.assertFalse(r.is_complete)

    def test_reset_clears_state(self):
        r = self._make_replayer()
        r.start(_build_log([(0, 0, 1.5, 0), (1, 0, 1.5, 1)]))
        r.reset()
        self.assertFalse(r.is_active)
        self.assertFalse(r.is_complete)
        self.assertEqual(r.get_waypoint_count(), 0)

    # ── reversal ──────────────────────────────────────────────────────────

    def test_first_waypoint_is_reversed(self):
        """The first waypoint should be in the region of the last recorded position.
        Note: 3-point smoothing pulls the endpoint toward its neighbours.
        We use a longer trajectory so the endpoint retains its approximate position."""
        r = self._make_replayer(arrival=0.1, home_radius=0.1)
        # Exploration: drone moved from origin along a smooth path toward (5, 5)
        log = _build_log([
            (0.0, 0.0, 1.5, 0.0),
            (1.0, 1.0, 1.5, 0.5),
            (2.0, 2.0, 1.5, 1.0),
            (3.5, 3.5, 1.5, 1.5),
            (5.0, 5.0, 1.5, 2.0),
            (5.0, 5.0, 1.5, 2.5),  # hold position at endpoint
        ])
        r.start(log)
        wp = r.get_current_target()
        self.assertIsNotNone(wp)
        # After reversal + smoothing the first waypoint should be in (5,5) region
        self.assertAlmostEqual(wp[0], 5.0, delta=2.0)
        self.assertAlmostEqual(wp[1], 5.0, delta=2.0)

    def test_last_waypoint_is_near_home(self):
        """The last waypoint in the reversed sequence should be the Home Pad."""
        r = self._make_replayer(arrival=0.1, home_radius=0.5)
        log = _build_log([(0.0, 0.0, 1.5, 0), (2.0, 2.0, 1.5, 1)])
        r.start(log)
        waypoints = r._waypoints
        last_wp = waypoints[-1]
        hx, hy = self.HOME
        self.assertAlmostEqual(last_wp[0], hx, delta=0.1)
        self.assertAlmostEqual(last_wp[1], hy, delta=0.1)

    # ── waypoint advancement ───────────────────────────────────────────────

    def test_get_next_waypoint_advances_when_arrived(self):
        """Returns None (complete) after reaching home radius."""
        hx, hy = self.HOME
        r = self._make_replayer(arrival=0.5, home_radius=0.4)
        # Single-waypoint path that is very close to home
        log = _build_log([(hx + 0.1, hy + 0.1, 1.5, 0)])
        r.start(log)
        # Drone is already at the single waypoint → advances and checks home
        wp = r.get_next_waypoint(hx + 0.1, hy + 0.1)
        # Should complete since we're within home radius
        self.assertIsNone(wp)
        self.assertTrue(r.is_complete)

    def test_not_complete_when_far_from_home(self):
        r = self._make_replayer(arrival=0.5, home_radius=0.4)
        log = _build_log([(5.0, 5.0, 1.5, 0), (3.0, 3.0, 1.5, 1)])
        r.start(log)
        wp = r.get_next_waypoint(5.0, 5.0)   # at first reversed waypoint ≈ (3,3)
        # Not at home yet → should return a waypoint or still be active
        self.assertFalse(r.is_complete)

    def test_complete_when_home_reached(self):
        hx, hy = self.HOME
        r = self._make_replayer(arrival=0.5, home_radius=0.4)
        log = _build_log([(5.0, 5.0, 1.5, 0)])
        r.start(log)
        # Simulate drone directly at home
        wp = r.get_next_waypoint(hx, hy)
        self.assertIsNone(wp)
        self.assertTrue(r.is_complete)

    def test_returns_none_when_inactive(self):
        r = self._make_replayer()
        wp = r.get_next_waypoint(0.0, 0.0)
        self.assertIsNone(wp)

    # ── progress ──────────────────────────────────────────────────────────

    def test_progress_starts_at_zero(self):
        r = self._make_replayer(arrival=0.1)
        log = _build_log([(5.0, 5.0, 1.5, 0), (3.0, 3.0, 1.5, 1)])
        r.start(log)
        self.assertAlmostEqual(r.get_progress(), 0.0, delta=0.01)

    def test_progress_is_one_when_complete(self):
        """is_complete should be True after home is reached, regardless of
        whether waypoints were individually consumed (home short-circuit)."""
        hx, hy = self.HOME
        r = self._make_replayer(arrival=0.5, home_radius=0.4)
        log = _build_log([(5.0, 5.0, 1.5, 0)])
        r.start(log)
        r.get_next_waypoint(hx, hy)    # trigger home completion
        self.assertTrue(r.is_complete)

    def test_empty_log_progress_one(self):
        r = self._make_replayer()
        self.assertAlmostEqual(r.get_progress(), 1.0)

    # ── serialisation ──────────────────────────────────────────────────────

    def test_snapshot_to_dict(self):
        snap = TrajectorySnapshot(
            timestamp=1.5, x=2.0, y=3.0, z=1.5,
            yaw=0.1, vx=0.5, vy=-0.2, vz=0.0
        )
        d = snap.to_dict()
        self.assertAlmostEqual(d['x'], 2.0)
        self.assertAlmostEqual(d['y'], 3.0)
        self.assertAlmostEqual(d['timestamp'], 1.5)
        self.assertIn('yaw', d)
        self.assertIn('vx', d)


if __name__ == "__main__":
    unittest.main(verbosity=2)

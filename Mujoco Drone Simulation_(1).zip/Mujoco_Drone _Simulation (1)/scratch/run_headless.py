import os
import sys
import time
import math
import numpy as np
import mujoco

# Ensure we can import from the workspace directory
sys.path.append(os.path.abspath("."))

from simulate import DroneAutopilot
from sensor_simulation import SensorSimulationSuite

def main():
    print("[HEADLESS] Loading MuJoCo model...")
    model = mujoco.MjModel.from_xml_path("scene.xml")
    data = mujoco.MjData(model)
    
    print("[HEADLESS] Initializing Autopilot and Sensor Suite...")
    ap = DroneAutopilot(model, data)
    sensor_suite = SensorSimulationSuite(dt=model.opt.timestep)

    # 1. Takeoff command
    ap.cmd_takeoff()
    print("[HEADLESS] Taking off (waiting for HOVER state)...")
    for step in range(1000):
        ap.step()
        mujoco.mj_step(model, data)
        sensor_suite.step(model, data)
        if ap.state == "HOVER":
            print(f"[HEADLESS] Hover reached at step {step}!")
            break
        
    print(f"[HEADLESS] Current state: {ap.state}")

    # 2. Scan terrain (360° spin)
    ap.cmd_scan()
    print("[HEADLESS] Scanning terrain (waiting for HOVER state)...")
    for step in range(2000):
        ap.step()
        mujoco.mj_step(model, data)
        sensor_suite.step(model, data)
        if ap.state == "HOVER":
            print(f"[HEADLESS] Scan completed at step {step}!")
            break
        
    print(f"[HEADLESS] Current state: {ap.state}")

    # 3. Fly to Pad 2
    print("[HEADLESS] Command: Fly to Pad 2...")
    ap.cmd_goto("Pad 2")
    
    print("[HEADLESS] Starting flight (Press S command)...")
    ap.cmd_toggle_path()  # Start the flight by enabling path tracking
    
    print("[HEADLESS] Navigating to Pad 2 (simulating max 40 seconds)...")
    for step in range(8000):
        ap.step()
        mujoco.mj_step(model, data)
        sensor_suite.step(model, data)
        
        # Periodically print progress
        if step % 500 == 0:
            qa = ap.qpos_adr
            print(f"  Step {step}: state={ap.state}, pos=({data.qpos[qa]:.2f}, {data.qpos[qa+1]:.2f}, {data.qpos[qa+2]:.2f})")
            
        if ap.state == "LANDED":
            print(f"[HEADLESS] Successfully landed at target pad at step {step}!")
            break
            
    print(f"[HEADLESS] Final flight state: {ap.state}")
    
    # Clean up and generate final sensor report + graph + json
    print("[HEADLESS] Flushing trajectory logs...")
    ap._flush_traj()
    
    print("[HEADLESS] Generating sensor filtering report and graphs...")
    sensor_suite.generate_plots_and_report()
    print("[HEADLESS] Complete!")

if __name__ == "__main__":
    main()

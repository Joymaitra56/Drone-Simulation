import mujoco
import sys
import os

# Append parent directory to path so we can import modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from simulate import DroneAutopilot
from mission_state import MissionState

def verify_integration():
    xml_path = "scene.xml"
    if not os.path.exists(xml_path):
        # Try parent directory if run from scratch folder
        xml_path = os.path.join("..", "scene.xml")
        if not os.path.exists(xml_path):
            print(f"Error: {xml_path} not found!")
            sys.exit(1)
            
    print(f"Loading MuJoCo model from {xml_path}...")
    model = mujoco.MjModel.from_xml_path(xml_path)
    data  = mujoco.MjData(model)
    
    print("Instantiating DroneAutopilot...")
    ap = DroneAutopilot(model, data)
    
    print("Verifying MissionManager initialization...")
    assert hasattr(ap, "mission_manager"), "Autopilot lacks mission_manager attribute!"
    assert ap.mission_manager is not None, "mission_manager is None!"
    assert ap.mission_manager.get_state() == MissionState.IDLE, f"Initial state is {ap.mission_manager.get_state()} instead of IDLE!"
    print(f"Success: MissionManager initialized to {ap.mission_manager.get_state()}.")
    
    print("Stepping Autopilot simulation once...")
    ap.step()
    print("Success: Step executed with zero errors.")
    
    print("\nINTEGRATION VERIFICATION SUCCESSFUL!")

if __name__ == '__main__':
    verify_integration()

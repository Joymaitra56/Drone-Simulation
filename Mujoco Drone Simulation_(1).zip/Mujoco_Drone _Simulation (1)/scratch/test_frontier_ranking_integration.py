import mujoco
import sys
import os

# Append parent directory to imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from simulate import DroneAutopilot
from sensor_simulation import SensorSimulationSuite
from frontier_ranking import FrontierRanking

def verify_frontier_ranking_integration():
    xml_path = "scene.xml"
    if not os.path.exists(xml_path):
        xml_path = os.path.join("..", "scene.xml")
        if not os.path.exists(xml_path):
            print(f"Error: {xml_path} not found!")
            sys.exit(1)
            
    print(f"Loading MuJoCo model from {xml_path}...")
    model = mujoco.MjModel.from_xml_path(xml_path)
    data  = mujoco.MjData(model)
    
    print("Instantiating DroneAutopilot and SensorSimulationSuite...")
    ap = DroneAutopilot(model, data)
    sensor_suite = SensorSimulationSuite(dt=model.opt.timestep)
    ap.sensor_suite = sensor_suite
    
    # Check that frontier_ranker is instantiated
    print("Verifying instantiation of FrontierRanking...")
    assert hasattr(ap, "frontier_ranker"), "Autopilot lacks frontier_ranker attribute!"
    ranker = ap.frontier_ranker
    assert ranker is not None, "frontier_ranker is None!"
    
    print("Running initial simulation steps to trigger mapping, frontier detection, and ranking...")
    # Step MuJoCo, sensor suite, and autopilot
    for _ in range(15):
        mujoco.mj_step(model, data)
        sensor_suite.step(model, data)
        ap.step()
        
    print("Querying frontier ranking statistics...")
    ranked = ranker.get_ranked_frontiers()
    best = ranker.get_best_frontier()
    scores = ranker.get_scores()
    
    print(f"Total ranked frontiers: {len(ranked)}")
    print(f"Scores list: {scores}")
    
    if best is not None:
        print("\nBest Frontier details:")
        print(f"  Region ID: {best['region_id']}")
        print(f"  Centroid: {best['centroid']}")
        print(f"  Size: {best['size']}")
        print(f"  Travel Cost: {best['travel_cost']}")
        print(f"  Information Gain: {best['info_gain']}")
        print(f"  Safety Score: {best['safety_score']}")
        print(f"  Reachability: {best['reachability']}")
        print(f"  Final Score: {best['score']:.4f}")
        
        # Basic assertions
        assert len(ranked) > 0, "Ranked list should not be empty!"
        assert best == ranked[0], "get_best_frontier() must return the first ranked element!"
        assert all(isinstance(s, float) for s in scores), "Scores list must contain floats!"
        
        # Verify scores are sorted in descending order
        for i in range(len(scores) - 1):
            assert scores[i] >= scores[i+1], f"Scores are not sorted: {scores[i]} < {scores[i+1]}"
            
        print("\nFRONTIER RANKING INTEGRATION VERIFICATION SUCCESSFUL!")
    else:
        # If no frontiers are found, check if that is expected (e.g. if count is 0)
        detector_regions = ap.frontier_detector.get_frontier_regions()
        assert len(detector_regions) == 0, "Detector found regions, but Ranker returned no best frontier!"
        print("\nNo frontiers found (expected since detector found 0 regions).")
        print("\nFRONTIER RANKING INTEGRATION VERIFICATION SUCCESSFUL!")

if __name__ == '__main__':
    verify_frontier_ranking_integration()

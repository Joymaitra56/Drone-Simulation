import unittest
import numpy as np
import time
from typing import Any

# Add parent directory to imports
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from sensor_fusion import FusedState
from frontier_ranking import FrontierRanking, CELL_UNKNOWN, CELL_FREE, CELL_OCCUPIED

class MockAutopilot:
    def __init__(self):
        self.grid_size = 160
        self.planner_algorithm = "A*"
        self.occ_grid = np.zeros((self.grid_size, self.grid_size), dtype=np.int8)

    def _world_to_grid(self, wx: float, wy: float) -> tuple:
        gs = self.grid_size
        gx = int(round((wx + 8.0) / 16.0 * (gs - 1)))
        gy = int(round((wy + 8.0) / 16.0 * (gs - 1)))
        return (max(0, min(gs-1, gx)), max(0, min(gs-1, gy)))

    def plan_path(self, start_g: tuple, goal_g: tuple) -> tuple:
        # Simple Euclidean distance as mock path cost
        dx = goal_g[0] - start_g[0]
        dy = goal_g[1] - start_g[1]
        dist = np.sqrt(dx*dx + dy*dy)
        
        # Simulate obstacle block (if target coordinate is near (100, 100) we mock unreachable)
        if goal_g == (100, 100):
            return None, float('inf')
            
        # Return path waypoints and cost
        return [(start_g[0], start_g[1]), (goal_g[0], goal_g[1])], dist

class TestFrontierRanking(unittest.TestCase):
    def setUp(self):
        self.mock_ap = MockAutopilot()
        self.grid_shape = (self.mock_ap.grid_size, self.mock_ap.grid_size)
        self.ranker = FrontierRanking(self.mock_ap)
        self.fused_state = FusedState(x=0.0, y=0.0, yaw=0.0, valid=True)

    def test_empty_frontiers(self):
        """Test ranker updates with an empty list of frontiers."""
        self.ranker.update([], self.mock_ap.occ_grid, self.fused_state)
        self.assertIsNone(self.ranker.get_best_frontier())
        self.assertEqual(len(self.ranker.get_ranked_frontiers()), 0)

    def test_single_frontier(self):
        """Test ranking of a single valid frontier region."""
        region = {
            "region_id": 1,
            "centroid_world": (2.0, 2.0),
            "centroid_grid": (100.0, 100.0), # (100, 100) is mocked unreachable in setUp
            "size": 5,
            "cells": [(100, 100)]
        }
        
        # Case A: Unreachable target (should be ignored)
        self.ranker.update([region], self.mock_ap.occ_grid, self.fused_state)
        self.assertIsNone(self.ranker.get_best_frontier())
        
        # Case B: Reachable target
        region["centroid_grid"] = (90.0, 90.0)
        region["cells"] = [(90, 90)]
        self.ranker.update([region], self.mock_ap.occ_grid, self.fused_state)
        
        best = self.ranker.get_best_frontier()
        self.assertIsNotNone(best)
        self.assertEqual(best["region_id"], 1)
        self.assertEqual(best["reachability"], 1.0)
        self.assertGreater(best["score"], 0.0)

    def test_multiple_frontiers_ranking(self):
        """Test ranking with multiple candidate frontiers at different distances."""
        # Drone is at x=0, y=0 -> grid=(80, 80)
        # Frontier A: Close to drone grid=(85, 80)
        # Frontier B: Far from drone grid=(120, 120)
        
        regions = [
            {
                "region_id": 1,
                "centroid_world": (4.0, 4.0),
                "centroid_grid": (120.0, 120.0),
                "size": 10,
                "cells": [(120, 120)]
            },
            {
                "region_id": 2,
                "centroid_world": (0.5, 0.0),
                "centroid_grid": (85.0, 80.0),
                "size": 10,
                "cells": [(85, 80)]
            }
        ]
        
        # Update ranking (Frontier A is closer and should rank higher due to lower travel cost)
        self.ranker.update(regions, self.mock_ap.occ_grid, self.fused_state)
        ranked = self.ranker.get_ranked_frontiers()
        
        self.assertEqual(len(ranked), 2)
        self.assertEqual(ranked[0]["region_id"], 2) # Closer should be best
        self.assertEqual(ranked[1]["region_id"], 1) # Farther should be second

    def test_tie_handling(self):
        """Test deterministic ordering of regions with identical features."""
        # Two identical regions at the same distance
        regions = [
            {
                "region_id": 1,
                "centroid_world": (1.0, 1.0),
                "centroid_grid": (90.0, 90.0),
                "size": 5,
                "cells": [(90, 90)]
            },
            {
                "region_id": 2,
                "centroid_world": (1.0, 1.0),
                "centroid_grid": (90.0, 90.0),
                "size": 5,
                "cells": [(90, 90)]
            }
        ]
        
        self.ranker.update(regions, self.mock_ap.occ_grid, self.fused_state)
        ranked = self.ranker.get_ranked_frontiers()
        
        # Sorted by final score, and then sorted deterministically by region_id (lowest ID first)
        self.assertEqual(ranked[0]["region_id"], 1)
        self.assertEqual(ranked[1]["region_id"], 2)

    def test_weight_configuration(self):
        """Test scoring configuration changes weight properties successfully."""
        # Custom weights favoring information gain heavily
        custom_weights = {
            "info_gain": 0.90,
            "travel_cost": 0.05,
            "safety": 0.05,
            "reachability": 0.0
        }
        ranker_custom = FrontierRanking(self.mock_ap, weights=custom_weights)
        
        # Frontier A: Close but little info gain
        # Frontier B: Far but massive info gain (surrounded by unknown cells)
        grid = np.zeros(self.grid_shape, dtype=np.int8)
        
        # Fill grid with CELL_UNKNOWN
        grid.fill(CELL_UNKNOWN)
        grid[80, 80] = CELL_FREE
        grid[85, 80] = CELL_FREE
        grid[120, 120] = CELL_FREE
        
        # Clear unknown status around Frontier A (85, 80) so that it has 0 info gain
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                grid[80 + dy, 85 + dx] = CELL_FREE
        
        regions = [
            {
                "region_id": 1, # Close
                "centroid_world": (0.5, 0.0),
                "centroid_grid": (85.0, 80.0),
                "size": 1,
                "cells": [(85, 80)]
            },
            {
                "region_id": 2, # Far
                "centroid_world": (4.0, 4.0),
                "centroid_grid": (120.0, 120.0),
                "size": 1,
                "cells": [(120, 120)]
            }
        ]
        
        # Update ranking (Frontier B should be best because weights strongly favor info gain)
        ranker_custom.update(regions, grid, self.fused_state)
        best = ranker_custom.get_best_frontier()
        self.assertEqual(best["region_id"], 2)

    def test_deterministic_ranking(self):
        """Verify deterministic output across multiple updates on identical states."""
        regions = [
            {"region_id": 1, "centroid_world": (1.0, 0.0), "centroid_grid": (90.0, 80.0), "size": 3, "cells": [(90, 80)]},
            {"region_id": 2, "centroid_world": (0.0, 1.0), "centroid_grid": (80.0, 90.0), "size": 3, "cells": [(80, 90)]}
        ]
        
        self.ranker.update(regions, self.mock_ap.occ_grid, self.fused_state)
        scores_1 = self.ranker.get_scores()
        
        self.ranker.update(regions, self.mock_ap.occ_grid, self.fused_state)
        scores_2 = self.ranker.get_scores()
        
        self.assertEqual(scores_1, scores_2)

    def test_performance_overhead(self):
        """Verify performance timing overhead is under 1.0 milliseconds (cache tests included)."""
        regions = []
        for i in range(50):
            regions.append({
                "region_id": i + 1,
                "centroid_world": (float(i)*0.1, 0.0),
                "centroid_grid": (80 + i, 80),
                "size": 5,
                "cells": [(80 + i, 80)]
            })
            
        iterations = 500
        t_start = time.perf_counter()
        for i in range(iterations):
            # Slightly vary position to bypass exact cache hit on every update,
            # simulating real-world updates
            fused = FusedState(x=float(i)*0.001, y=0.0, yaw=0.0, valid=True)
            self.ranker.update(regions, self.mock_ap.occ_grid, fused)
        t_end = time.perf_counter()
        
        elapsed = t_end - t_start
        avg_time = elapsed / iterations
        print(f"\n[RANKING BENCHMARK] Elapsed: {elapsed:.4f}s for {iterations} iterations.")
        print(f"[RANKING BENCHMARK] Average overhead: {avg_time * 1e3:.3f} milliseconds.")
        
        # Verify average execution time is under 1 millisecond
        self.assertLess(avg_time, 0.001)

if __name__ == '__main__':
    unittest.main()

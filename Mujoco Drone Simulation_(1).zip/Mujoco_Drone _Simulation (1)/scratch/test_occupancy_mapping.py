import unittest
import numpy as np
import time
from typing import Any

# Add parent directory to imports
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from sensor_fusion import FusedState
from occupancy_grid_mapping import OccupancyGridMapping, CELL_UNKNOWN, CELL_FREE, CELL_OCCUPIED

class MockScanner:
    def __init__(self, grid_size: int = 160):
        self.grid_size = grid_size
        self.sensor_radius = 2.5
        self.fov_rad = np.radians(90.0)
        self.sensor_type = "directional"
        
        self.ground_truth_grid = np.zeros((grid_size, grid_size), dtype=np.int8)
        self.discovered_grid = np.full((grid_size, grid_size), CELL_UNKNOWN, dtype=np.int8)
        self.explored_mask = np.zeros((grid_size, grid_size), dtype=bool)
        
        # Pre-reveal pads to populate CELL_FREE in discovered_grid initially
        self._reveal_landing_pads()

    def _world_to_grid(self, wx: float, wy: float) -> tuple:
        gs = self.grid_size
        gx = int(round((wx + 8.0) / 16.0 * (gs - 1)))
        gy = int(round((wy + 8.0) / 16.0 * (gs - 1)))
        return (max(0, min(gs-1, gx)), max(0, min(gs-1, gy)))

    def _grid_to_world(self, gx: int, gy: int) -> tuple:
        gs = self.grid_size
        wx = -8.0 + 16.0 * gx / (gs - 1)
        wy = -8.0 + 16.0 * gy / (gs - 1)
        return wx, wy

    def _reveal_landing_pads(self):
        # Mock pre-reveal by clearing a small patch at (0, 0)
        self.discovered_grid[75:85, 75:85] = CELL_FREE

    def get_planning_grid(self) -> np.ndarray:
        grid = np.copy(self.discovered_grid)
        grid[grid == CELL_UNKNOWN] = 0
        return grid

class MockAutopilot:
    def __init__(self):
        self.grid_size = 160
        self.scanner = MockScanner(self.grid_size)
        self.occ_grid = self.scanner.get_planning_grid()

class TestOccupancyGridMapping(unittest.TestCase):
    def setUp(self):
        self.mock_ap = MockAutopilot()
        self.mapper = OccupancyGridMapping(self.mock_ap)

    def test_initialization(self):
        """Test default mapping and grid states upon initialization."""
        stats = self.mapper.get_statistics()
        self.assertEqual(stats["total_cells"], 160 * 160)
        self.assertGreater(stats["free_cells"], 0)
        self.assertEqual(stats["occupied_cells"], 0)
        
        grid = self.mapper.get_grid()
        self.assertEqual(grid.shape, (160, 160))

    def test_incremental_update_occupied(self):
        """Test that single observations update log-odds and transition to occupied after accumulation."""
        fused = FusedState(x=0.0, y=0.0, yaw=0.0, valid=True)
        scanner = self.mock_ap.scanner
        
        # Place an obstacle in front of the drone in ground truth
        gx, gy = scanner._world_to_grid(1.0, 0.0)
        scanner.ground_truth_grid[gy, gx] = CELL_OCCUPIED

        # Update 1: log-odds should rise but not yet reach OCCUPIED threshold (+0.8 < 1.0)
        self.mapper.update(fused, None)
        self.assertEqual(scanner.discovered_grid[gy, gx], CELL_UNKNOWN)

        # Update 2: log-odds accumulates (+1.6 >= 1.0), cell state should transition to occupied
        self.mapper.update(fused, None)
        self.assertEqual(scanner.discovered_grid[gy, gx], CELL_OCCUPIED)

    def test_incremental_update_free(self):
        """Test that free space updates log-odds and transition to free after threshold."""
        fused = FusedState(x=0.0, y=0.0, yaw=0.0, valid=True)
        scanner = self.mock_ap.scanner
        
        # Place free space in front of the drone in ground truth
        gx, gy = scanner._world_to_grid(1.0, 0.0)
        scanner.ground_truth_grid[gy, gx] = CELL_FREE

        # Update 1: log-odds decreases (-0.4 > -1.0)
        self.mapper.update(fused, None)
        self.assertEqual(scanner.discovered_grid[gy, gx], CELL_UNKNOWN)

        # Update 3: log-odds drops below threshold (-1.2 <= -1.0), cell state transitions to free
        self.mapper.update(fused, None)
        self.mapper.update(fused, None)
        self.assertEqual(scanner.discovered_grid[gy, gx], CELL_FREE)

    def test_grid_reset(self):
        """Test resetting map reverts cells to unknown/initial pre-revealed status."""
        fused = FusedState(x=0.0, y=0.0, yaw=0.0, valid=True)
        scanner = self.mock_ap.scanner
        
        # Perform updates
        self.mapper.update(fused, None)
        
        # Reset and check
        self.mapper.reset()
        stats = self.mapper.get_statistics()
        self.assertEqual(stats["occupied_cells"], 0)
        self.assertEqual(np.sum(self.mapper.log_odds != 0.0), stats["free_cells"])

    def test_performance_overhead(self):
        """Benchmark performance and verify negligible update overhead (< 1ms)."""
        fused = FusedState(x=0.0, y=0.0, yaw=0.0, valid=True)
        
        iterations = 500
        t_start = time.perf_counter()
        for _ in range(iterations):
            self.mapper.update(fused, None)
        t_end = time.perf_counter()
        
        elapsed = t_end - t_start
        avg_time = elapsed / iterations
        print(f"\n[MAP BENCHMARK] Elapsed: {elapsed:.4f}s for {iterations} runs.")
        print(f"[MAP BENCHMARK] Average mapping overhead: {avg_time * 1e3:.3f} milliseconds.")
        self.assertLess(avg_time, 0.001)

    def test_long_duration_stability(self):
        """Simulate high-frequency mapping updates to verify numerical stability and zero overflows."""
        fused = FusedState(x=0.0, y=0.0, yaw=0.0, valid=True)
        scanner = self.mock_ap.scanner
        
        # Alternate obstacle updates
        gx, gy = scanner._world_to_grid(1.0, 0.0)
        for i in range(1000):
            scanner.ground_truth_grid[gy, gx] = CELL_OCCUPIED if i % 2 == 0 else CELL_FREE
            self.mapper.update(fused, None)
            
        # Assert values remain within log-odds clamp bounds
        self.assertTrue(np.all(self.mapper.log_odds >= self.mapper.min_log_odds))
        self.assertTrue(np.all(self.mapper.log_odds <= self.mapper.max_log_odds))
        self.assertFalse(np.any(np.isnan(self.mapper.log_odds)))

if __name__ == '__main__':
    unittest.main()

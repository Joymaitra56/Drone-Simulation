"""
Unit tests for post_mission_analysis.py

Tests cover:
  - PadRoute serialisation
  - PostMissionAnalysis.run() with mock planners
  - Route reachability detection
  - Summary statistics
  - get_best_route() lookup
"""

import sys
import os
import math
import json
import unittest
import tempfile

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from post_mission_analysis import PostMissionAnalysis, PadRoute, _world_to_grid


# ---------------------------------------------------------------------------
# Mock planners
# ---------------------------------------------------------------------------

def _mock_astar(grid, start, goal):
    """Returns a trivial straight-line path between two grid cells."""
    gx0, gy0 = start
    gx1, gy1 = goal
    # Produce a list of (col, row) from start to goal via simple stepping
    path = []
    dx = gx1 - gx0
    dy = gy1 - gy0
    steps = max(abs(dx), abs(dy), 1)
    for i in range(steps + 1):
        path.append((gx0 + round(dx * i / steps),
                     gy0 + round(dy * i / steps)))
    cost = float(len(path))
    return path, cost


def _mock_dijkstra(grid, start, goal):
    """Same as mock A* but returns 2× the cost for differentiation."""
    path, cost = _mock_astar(grid, start, goal)
    return path, cost * 2.0


def _mock_unreachable(grid, start, goal):
    """Always returns no path."""
    return None, float('inf')


# ---------------------------------------------------------------------------
# Test pads
# ---------------------------------------------------------------------------

_TEST_PADS = [
    ("Home",  -4.0, -4.0, 0.6),
    ("Pad 1", -4.0,  4.0, 0.4),
    ("Pad 2",  4.0,  4.0, 0.4),
]


class TestPadRoute(unittest.TestCase):
    """Unit tests for PadRoute container."""

    def _make_route(self, **kwargs):
        defaults = dict(
            pad_a="Home", pad_b="Pad 1", algorithm="A*",
            path_length=10, travel_cost=9.5, computation_ms=1.2,
            reachable=True, path_grid=[(0, 0), (1, 1)],
        )
        defaults.update(kwargs)
        return PadRoute(**defaults)

    def test_to_dict_keys(self):
        r = self._make_route()
        d = r.to_dict()
        self.assertIn("pad_a", d)
        self.assertIn("pad_b", d)
        self.assertIn("algorithm", d)
        self.assertIn("path_length_waypoints", d)
        self.assertIn("travel_cost", d)
        self.assertIn("computation_time_ms", d)
        self.assertIn("reachable", d)

    def test_to_dict_values(self):
        r = self._make_route(travel_cost=9.5)
        d = r.to_dict()
        self.assertAlmostEqual(d["travel_cost"], 9.5, places=3)
        self.assertTrue(d["reachable"])

    def test_unreachable_cost_is_none(self):
        r = self._make_route(reachable=False, travel_cost=float('inf'))
        d = r.to_dict()
        self.assertIsNone(d["travel_cost"])


class TestPostMissionAnalysis(unittest.TestCase):
    """Integration-style tests for PostMissionAnalysis."""

    def setUp(self):
        self.grid = np.zeros((160, 160), dtype=np.int8)  # all free
        self.analysis = PostMissionAnalysis(pads=_TEST_PADS, grid_size=160)

    # ── run() ─────────────────────────────────────────────────────────────

    def test_run_returns_list_of_dicts(self):
        results = self.analysis.run(self.grid, _mock_astar, _mock_dijkstra)
        self.assertIsInstance(results, list)
        self.assertGreater(len(results), 0)
        for r in results:
            self.assertIn("pad_a", r)
            self.assertIn("algorithm", r)

    def test_run_produces_correct_pair_count(self):
        """n*(n-1)/2 pairs × 2 algorithms = n*(n-1) routes."""
        n = len(_TEST_PADS)
        expected = n * (n - 1)  # pairs * 2 algos
        results = self.analysis.run(self.grid, _mock_astar, _mock_dijkstra)
        self.assertEqual(len(results), expected)

    def test_all_routes_reachable_on_free_grid(self):
        self.analysis.run(self.grid, _mock_astar, _mock_dijkstra)
        for r in self.analysis.routes:
            self.assertTrue(r.reachable, f"Route {r.pad_a}→{r.pad_b} should be reachable")

    def test_unreachable_routes_detected(self):
        self.analysis.run(self.grid, _mock_unreachable, _mock_unreachable)
        for r in self.analysis.routes:
            self.assertFalse(r.reachable)
            self.assertEqual(r.path_length, 0)

    def test_astar_and_dijkstra_in_results(self):
        self.analysis.run(self.grid, _mock_astar, _mock_dijkstra)
        algos = {r.algorithm for r in self.analysis.routes}
        self.assertIn("A*", algos)
        self.assertIn("Dijkstra", algos)

    def test_dijkstra_cost_higher_than_astar(self):
        """Our mock Dijkstra returns 2× cost, so Dijkstra > A*."""
        self.analysis.run(self.grid, _mock_astar, _mock_dijkstra)
        for r_astar in self.analysis.routes:
            if r_astar.algorithm != "A*" or not r_astar.reachable:
                continue
            r_dijk = self.analysis.get_best_route(r_astar.pad_a, r_astar.pad_b, "Dijkstra")
            if r_dijk and r_dijk.reachable:
                self.assertGreater(r_dijk.travel_cost, r_astar.travel_cost)

    # ── path_grid stored correctly ─────────────────────────────────────────

    def test_path_grid_not_empty_for_reachable(self):
        self.analysis.run(self.grid, _mock_astar, _mock_dijkstra)
        for r in self.analysis.routes:
            if r.reachable:
                self.assertGreater(len(r.path_grid), 0)

    def test_path_grid_empty_for_unreachable(self):
        self.analysis.run(self.grid, _mock_unreachable, _mock_dijkstra)
        for r in self.analysis.routes:
            if r.algorithm == "A*" and not r.reachable:
                self.assertEqual(len(r.path_grid), 0)

    # ── get_best_route ─────────────────────────────────────────────────────

    def test_get_best_route_found(self):
        self.analysis.run(self.grid, _mock_astar, _mock_dijkstra)
        r = self.analysis.get_best_route("Home", "Pad 1", "A*")
        self.assertIsNotNone(r)
        self.assertEqual(r.pad_a, "Home")
        self.assertEqual(r.pad_b, "Pad 1")

    def test_get_best_route_reversed_pair(self):
        """Should find the route regardless of pad_a/pad_b order."""
        self.analysis.run(self.grid, _mock_astar, _mock_dijkstra)
        r = self.analysis.get_best_route("Pad 1", "Home", "A*")
        self.assertIsNotNone(r)

    def test_get_best_route_unknown_returns_none(self):
        self.analysis.run(self.grid, _mock_astar, _mock_dijkstra)
        r = self.analysis.get_best_route("Home", "Nonexistent", "A*")
        self.assertIsNone(r)

    # ── is_completed flag ─────────────────────────────────────────────────

    def test_not_completed_before_run(self):
        fresh = PostMissionAnalysis(pads=_TEST_PADS, grid_size=160)
        self.assertFalse(fresh.is_completed)

    def test_completed_after_run(self):
        self.analysis.run(self.grid, _mock_astar, _mock_dijkstra)
        self.assertTrue(self.analysis.is_completed)

    # ── save_results (to temp file) ────────────────────────────────────────

    def test_save_results_creates_valid_json(self):
        self.analysis.run(self.grid, _mock_astar, _mock_dijkstra)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            tmp_path = f.name
        try:
            self.analysis.save_results(tmp_path)
            with open(tmp_path) as f:
                data = json.load(f)
            self.assertIn("summary", data)
            self.assertIn("routes", data)
            self.assertIn("comparison", data)
            self.assertIsInstance(data["routes"], list)
        finally:
            os.unlink(tmp_path)

    def test_save_results_summary_correct_pad_count(self):
        self.analysis.run(self.grid, _mock_astar, _mock_dijkstra)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            tmp_path = f.name
        try:
            self.analysis.save_results(tmp_path)
            with open(tmp_path) as f:
                data = json.load(f)
            self.assertEqual(data["summary"]["total_pads"], len(_TEST_PADS))
        finally:
            os.unlink(tmp_path)

    # ── coordinate helpers ─────────────────────────────────────────────────

    def test_world_to_grid_bounds(self):
        """Corner world positions should map to grid corners."""
        gx, gy = _world_to_grid(-8.0, -8.0, 160)
        self.assertEqual(gx, 0)
        self.assertEqual(gy, 0)
        gx, gy = _world_to_grid(8.0, 8.0, 160)
        self.assertEqual(gx, 159)
        self.assertEqual(gy, 159)

    def test_world_to_grid_clamps(self):
        """Out-of-bounds world coords should clamp to valid grid range."""
        gx, gy = _world_to_grid(-100.0, 100.0, 160)
        self.assertEqual(gx, 0)
        self.assertEqual(gy, 159)


if __name__ == "__main__":
    unittest.main(verbosity=2)
